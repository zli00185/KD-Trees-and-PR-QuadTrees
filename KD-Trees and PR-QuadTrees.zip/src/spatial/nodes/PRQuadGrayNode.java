package spatial.nodes;

import spatial.exceptions.UnimplementedMethodException;
import spatial.kdpoint.KDPoint;
import spatial.knnutils.BoundedPriorityQueue;
import spatial.knnutils.NNData;
import spatial.trees.CentroidAccuracyException;
import spatial.trees.PRQuadTree;

import java.util.ArrayList;
import java.util.Collection;

/** <p>A {@link PRQuadGrayNode} is a gray (&quot;mixed&quot;) {@link PRQuadNode}. It
 * maintains the following invariants: </p>
 * <ul>
 *      <li>Its children pointer buffer is non-null and has a length of 4.</li>
 *      <li>If there is at least one black node child, the total number of {@link KDPoint}s stored
 *      by <b>all</b> of the children is greater than the bucketing parameter (because if it is equal to it
 *      or smaller, we can prune the node.</li>
 * </ul>
 *
 * <p><b>YOU ***** MUST ***** IMPLEMENT THIS CLASS!</b></p>
 *
 *  @author --- YOUR NAME HERE! ---
 */
public class PRQuadGrayNode extends PRQuadNode{


    /* ******************************************************************** */
    /* *************  PLACE ANY  PRIVATE FIELDS AND METHODS HERE: ************ */
    /* ********************************************************************** */

	private PRQuadNode NW;
	private PRQuadNode NE;
	private PRQuadNode SW;
	private PRQuadNode SE;
	
	public PRQuadNode get_NW() {
		return NW;
	}
	
	public PRQuadNode get_NE() {
		return NE;
	}
	public PRQuadNode get_SW() {
		return SW;
	}
	public PRQuadNode get_SE() {
		return SE;
	}
	
	private ArrayList<KDPoint> getlistFromChildren(PRQuadNode child){
		ArrayList<KDPoint> output = new ArrayList<KDPoint>();
		if(child == null) {
			
			return output;
		}
		
		if(child instanceof PRQuadBlackNode ) {
			return (ArrayList<KDPoint>) ((PRQuadBlackNode) child).getPoints();
			
		}else{
			
			
			output.addAll(getlistFromChildren(((PRQuadGrayNode) child).get_NW()));
			output.addAll(getlistFromChildren(((PRQuadGrayNode) child).get_NE()));
			output.addAll(getlistFromChildren(((PRQuadGrayNode) child).get_SW()));
			output.addAll(getlistFromChildren(((PRQuadGrayNode) child).get_SE()));
			
			return output;
		}
		
	}
	
	
    /* *********************************************************************** */
    /* ***************  IMPLEMENT THE FOLLOWING PUBLIC METHODS:  ************ */
    /* *********************************************************************** */

    /**
     * Creates a {@link PRQuadGrayNode}  with the provided {@link KDPoint} as a centroid;
     * @param centroid A {@link KDPoint} that will act as the centroid of the space spanned by the current
     *                 node.
     * @param k The See {@link PRQuadTree#PRQuadTree(int, int)} for more information on how this parameter works.
     * @param bucketingParam The bucketing parameter fed to this by {@link PRQuadTree}.
     * @see PRQuadTree#PRQuadTree(int, int)
     */
    public PRQuadGrayNode(KDPoint centroid, int k, int bucketingParam){
        super(centroid, k, bucketingParam); // Call to the super class' protected constructor to properly initialize the object!
        
    }


    /**
     * <p>Insertion into a {@link PRQuadGrayNode} consists of navigating to the appropriate child
     * and recursively inserting elements into it. If the child is a white node, memory should be allocated for a
     * {@link PRQuadBlackNode} which will contain the provided {@link KDPoint} If it's a {@link PRQuadBlackNode},
     * refer to {@link PRQuadBlackNode#insert(KDPoint, int)} for details on how the insertion is performed. If it's a {@link PRQuadGrayNode},
     * the current method would be called recursively. Polymorphism will allow for the appropriate insert to be called
     * based on the child object's runtime object.</p>
     * @param p A {@link KDPoint} to insert into the subtree rooted at the current {@link PRQuadGrayNode}.
     * @param k The side length of the quadrant spanned by the <b>current</b> {@link PRQuadGrayNode}. It will need to be updated
     *          per recursive call to help guide the input {@link KDPoint}  to the appropriate subtree.
     * @return The subtree rooted at the current node, potentially adjusted after insertion.
     * @see PRQuadBlackNode#insert(KDPoint, int)
     */
    @Override
    public PRQuadNode insert(KDPoint p, int k) {
       int x_cent = this.centroid.coords[0];
       int y_cent = this.centroid.coords[1];
       int x_coord = p.coords[0];
       int y_coord = p.coords[1];
    	
        if(x_coord>= x_cent && y_coord>= y_cent) {
    	   //NE
    	   if(NE==null) {
    		   
    		  int new_center_x = (int) (x_cent+ Math.pow(2, this.k-2)) ;
    		  int new_center_y = (int) (y_cent+ Math.pow(2, this.k-2)) ;
    		   
    		  NE = new PRQuadBlackNode(new KDPoint(new_center_x, new_center_y), this.k-1, bucketingParam, p);
    		 
    		   
    	   }else {
    		   //* NE exist, but need to check bucket size, but blacknode insert can take care of it
    		  NE =  NE.insert(p, k);
    		   
    	   }
    	   
    	   
    	   
    	   
       }else if(x_coord < x_cent && y_coord>= y_cent) {
    	   //NW
    	   if(NW==null) {
    		   
     		  int new_center_x = (int) (x_cent - Math.pow(2, this.k-2)) ;
     		  int new_center_y = (int) (y_cent + Math.pow(2, this.k-2)) ;
     		   
     		  NW = new PRQuadBlackNode(new KDPoint(new_center_x, new_center_y), this.k-1, bucketingParam, p);
     		 
     		   
     	   }else {
     		   //* NW exist, but need to check bucket size, but blacknode insert can take care of it
     		  NW =  NW.insert(p, k);
     		   
     	   }
    	   
    	   
    	   
       }else if(x_coord>= x_cent && y_coord < y_cent) {
    	   //SE
    	   if(SE==null) {
    		   
     		  int new_center_x = (int) (x_cent+ Math.pow(2, this.k-2)) ;
     		  int new_center_y = (int) (y_cent - Math.pow(2, this.k-2)) ;
     		   
     		  SE = new PRQuadBlackNode(new KDPoint(new_center_x, new_center_y), this.k-1, bucketingParam, p);
     		 
     		   
     	   }else {
     		   //* SE exist, but need to check bucket size, but blacknode insert can take care of it
     		   SE = SE.insert(p, k);
     		   
     	   }
    	   
    	   
       }else {
    	   //SW
    	   if(SW==null) {
    		   
      		  int new_center_x = (int) (x_cent - Math.pow(2, this.k-2)) ;
      		  int new_center_y = (int) (y_cent - Math.pow(2, this.k-2)) ;
      		   
      		  SW = new PRQuadBlackNode(new KDPoint(new_center_x, new_center_y), this.k-1, bucketingParam, p);
      		 
      		   
      	   }else {
      		   //* SW exist, but need to check bucket size, but blacknode insert can take care of it
      		   SW = SW.insert(p, k);
      		   
      	   }
       }
    	
    	return this;
    }

    /**
     * <p>Deleting a {@link KDPoint} from a {@link PRQuadGrayNode} consists of recursing to the appropriate
     * {@link PRQuadBlackNode} child to find the provided {@link KDPoint}. If no such child exists, the search has
     * <b>necessarily failed</b>; <b>no changes should then be made to the subtree rooted at the current node!</b></p>
     *
     * <p>Polymorphism will allow for the recursive call to be made into the appropriate delete method.
     * Importantly, after the recursive deletion call, it needs to be determined if the current {@link PRQuadGrayNode}
     * needs to be collapsed into a {@link PRQuadBlackNode}. This can only happen if it has no gray children, and one of the
     * following two conditions are satisfied:</p>
     *
     * <ol>
     *     <li>The deletion left it with a single black child. Then, there is no reason to further subdivide the quadrant,
     *     and we can replace this with a {@link PRQuadBlackNode} that contains the {@link KDPoint}s that the single
     *     black child contains.</li>
     *     <li>After the deletion, the <b>total</b> number of {@link KDPoint}s contained by <b>all</b> the black children
     *     is <b>equal to or smaller than</b> the bucketing parameter. We can then similarly replace this with a
     *     {@link PRQuadBlackNode} over the {@link KDPoint}s contained by the black children.</li>
     *  </ol>
     *
     * @param p A {@link KDPoint} to delete from the tree rooted at the current node.
     * @return The subtree rooted at the current node, potentially adjusted after deletion.
     */
    @Override
    public PRQuadNode delete(KDPoint p) {
        if(!search(p)) {
        	return this;
        }
    	
        int x_cent = this.centroid.coords[0];
        int y_cent = this.centroid.coords[1];
        int x_coord = p.coords[0];
        int y_coord = p.coords[1];
        System.out.println("delete: "+ p);
        if(x_coord>= x_cent && y_coord>= y_cent) {
      	   //NE
      	   
        	NE = NE.delete(p);
        	
         }else if(x_coord < x_cent && y_coord>= y_cent) {
      	   //NW
      	   
        	 NW = NW.delete(p);
      	   
         }else if(x_coord>= x_cent && y_coord < y_cent) {
      	   //SE
      	  
        	 SE = SE.delete(p);
      	   
         }else {
      	   //SW
      	   
        	SW =SW.delete(p);
        	 
         }
        
        //*NE == null&&NW == null&&SE == null&&SW == null
        if(count() == 0 ) {
        	System.out.println("merge to white node");
            //* become a white node
        	return null;
        	
        }else if(count()<= this.bucketingParam) {
        //*become a black node
        	System.out.println("merge to black node");
        	ArrayList<KDPoint> list = getlistFromChildren(this);
        	
        	PRQuadBlackNode black = new PRQuadBlackNode(this.centroid, this.k, bucketingParam);
        	
        	for(int i = 0; i< list.size(); i++) {
        		//* k what use?
        		black.insert(list.get(i), k);
        	}
        		
        	return black;
        }
        return this;
    	
    }

    @Override
    public boolean search(KDPoint p){
    	int x_cent = this.centroid.coords[0];
        int y_cent = this.centroid.coords[1];
        int x_coord = p.coords[0];
        int y_coord = p.coords[1];
     	
        if(x_coord>= x_cent && y_coord>= y_cent) {
     	   //NE
     	   if(NE==null) {
     		  return false; 
     		  
     	   }else {
     		  return NE.search(p);
     		  
     	   }
     	   
        }else if(x_coord < x_cent && y_coord>= y_cent) {
     	   //NW
     	   if(NW==null) {
     		  return false;
      	   }else {
      		   
      		  return NW.search(p);
      	   }
     	   
        }else if(x_coord>= x_cent && y_coord < y_cent) {
     	   //SE
     	   if(SE==null) {
     		   return false;
      	   }else {
      		   
      		   return SE.search(p);
      	   }
     	   
     	   
        }else {
     	   //SW
     	   if(SW ==null) {
       		   return false;
       	   }else {
       		   
       		   return SW.search(p);
       	   }
        }
    	
    	
    }

    
   
    
    
    
    @Override
    public int height(){
    	int output = -1;
    	int NWhe = -1;
    	int NEhe = -1;
    	int SWhe = -1;
    	int SEhe = -1;
    	
    	if(NW !=null) {
    		NWhe = NW.height();
    	}

    	if(NE !=null) {
    		NEhe = NE.height();
    	}
    	
    	if(SE !=null) {
    		SEhe = SE.height();
    	}
    	
    	if(SW !=null) {
    		SWhe = SW.height();
    	}
    	
    	
    	
    	
        if(NWhe> NEhe) {
        	output = NWhe;
        }else {
        	output = NEhe;
        }
    	
        if(output> SWhe) {
        	
        }else {
        	output = SWhe;
        }
        
        if(output> SEhe) {
        	
        }else {
        	output = SEhe;
        }
        
        
    	
    	return output + 1;
    	
    }

    @Override
    public int count(){
    	int NE_count = 0;
        int NW_count = 0;
        int SE_count = 0;
        int SW_count = 0;
        
        if(NE != null) {
        	NE_count = NE.count();
        }
        
        if(SE != null) {
        	SE_count = SE.count();
        }
        if(NW != null) {
        	NW_count = NW.count();
        }
        
        if(SW != null) {
        	SW_count = SW.count();
        }
        
        int total = NE_count+NW_count+SW_count+SE_count;
    	
    	return total;
    }

    /**
     * Returns the children of the current node in the form of a Z-ordered 1-D array.
     * @return An array of references to the children of {@code this}. The order is Z (Morton), like so:
     * <ol>
     *     <li>0 is NW</li>
     *     <li>1 is NE</li>
     *     <li>2 is SW</li>
     *     <li>3 is SE</li>
     * </ol>
     */
    public PRQuadNode[] getChildren(){
        PRQuadNode[] output = new PRQuadNode[4];
        output[0] = NW;
        output[0] = NE;
        output[0] = SW;
        output[0] = SE;
        return output;
    }

    @Override
    public void range(KDPoint anchor, Collection<KDPoint> results,
                      double range) {
    	int x_cent = this.centroid.coords[0];
        int y_cent = this.centroid.coords[1];
        int x_anchor = anchor.coords[0];
        int y_anchor = anchor.coords[1];
        
        if(x_anchor>= x_cent&& y_anchor>= y_cent) {
        	//* NE -> NW -> SW -> SE
        	if(NE!=null) {
        		if(NE.doesQuadIntersectAnchorRange(anchor, range)) {
        			NE.range(anchor, results, range);
        		}
        	}
        	
        	
	        if(NW!=null) {
	        	if(NW.doesQuadIntersectAnchorRange(anchor, range)) {
	        		NW.range(anchor, results, range);
	        	}
	        }
        	
        	
        	if(SW!=null) {
        		if(SW.doesQuadIntersectAnchorRange(anchor, range)) {
        			SW.range(anchor, results, range);
        		}
        	}
        	
        	if(SE!=null) {
        		if(SE.doesQuadIntersectAnchorRange(anchor, range)) {
        			SE.range(anchor, results, range);
        		}
        	}
        	
        	
        	
        }else if(x_anchor < x_cent&& y_anchor>= y_cent) {
        	//* NW -> NE -> SW -> SE
        	
	        if(NW!=null) {
	        	if(NW.doesQuadIntersectAnchorRange(anchor, range)) {
	        		NW.range(anchor, results, range);
	        	}
	        }
        	
        	
        	if(NE!=null) {
        		if(NE.doesQuadIntersectAnchorRange(anchor, range)) {
        			NE.range(anchor, results, range);
        		}
        	}
        	
        	
        	if(SW!=null) {
        		if(SW.doesQuadIntersectAnchorRange(anchor, range)) {
        			SW.range(anchor, results, range);
        		}
        	}
        	
        	if(SE!=null) {
        		if(SE.doesQuadIntersectAnchorRange(anchor, range)) {
        			SE.range(anchor, results, range);
        		}
        	}
        	
        }else if(x_anchor>= x_cent&& y_anchor < y_cent) {
        	//* SE -> NW -> NE -> SW
        	
        	if(SE!=null) {
        		if(SE.doesQuadIntersectAnchorRange(anchor, range)) {
        			SE.range(anchor, results, range);
        		}
        	}
        	
        	if(NW!=null) {
	        	if(NW.doesQuadIntersectAnchorRange(anchor, range)) {
	        		NW.range(anchor, results, range);
	        	}
	        }
        	
        	if(NE!=null) {
        		if(NE.doesQuadIntersectAnchorRange(anchor, range)) {
        			NE.range(anchor, results, range);
        		}
        	}
        	
        	if(SW!=null) {
	        	if(SW.doesQuadIntersectAnchorRange(anchor, range)) {
	        		SW.range(anchor, results, range);
	        	}
	        }
	        
        	
        }else {
        	//* SW -> NW -> NE -> SE

        	if(SW!=null) {
        		if(SW.doesQuadIntersectAnchorRange(anchor, range)) {
        			SW.range(anchor, results, range);
        		}
        	}
        	
        	
	        if(NW!=null) {
	        	if(NW.doesQuadIntersectAnchorRange(anchor, range)) {
	        		NW.range(anchor, results, range);
	        	}
	        }
        	
	        if(NE!=null) {
        		if(NE.doesQuadIntersectAnchorRange(anchor, range)) {
        			NE.range(anchor, results, range);
        		}
        	}
	        
        	
        	if(SE!=null) {
        		if(SE.doesQuadIntersectAnchorRange(anchor, range)) {
        			SE.range(anchor, results, range);
        		}
        	}
        	
        }
    	
    	
    	
    	
    	
    }

    @Override
    public NNData<KDPoint> nearestNeighbor(KDPoint anchor, NNData<KDPoint> n)  {
    	int x_cent = this.centroid.coords[0];
        int y_cent = this.centroid.coords[1];
        int x_anchor = anchor.coords[0];
        int y_anchor = anchor.coords[1];
        
        if(x_anchor>= x_cent&& y_anchor>= y_cent) {
        	//* NE -> NW -> SW -> SE
        	if(NE!=null) {
        		if(NE.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
        			n = NE.nearestNeighbor(anchor, n);
        		}
        	}
        	
        	
	        if(NW!=null) {
	        	if(NW.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
	        		n = NW.nearestNeighbor(anchor, n);
	        	}
	        }
        	
        	
        	if(SW!=null) {
        		if(SW.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
        			n = SW.nearestNeighbor(anchor, n);
        		}
        	}
        	
        	if(SE!=null) {
        		if(SE.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
        			n = SE.nearestNeighbor(anchor, n);
        		}
        	}
        	
        	
        	
        }else if(x_anchor < x_cent&& y_anchor>= y_cent) {
        	//* NW -> NE -> SW -> SE
        	
	        if(NW!=null) {
	        	if(NW.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
	        		n = NW.nearestNeighbor(anchor, n);
	        	}
	        }
        	
        	
        	if(NE!=null) {
        		if(NE.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
        			n = NE.nearestNeighbor(anchor, n);
        		}
        	}
        	
        	
        	if(SW!=null) {
        		if(SW.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
        			n = SW.nearestNeighbor(anchor, n);
        		}
        	}
        	
        	if(SE!=null) {
        		if(SE.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
        			n = SE.nearestNeighbor(anchor, n);
        		}
        	}
        	
        }else if(x_anchor>= x_cent&& y_anchor < y_cent) {
        	//* SE -> NW -> NE -> SW
        	
        	if(SE!=null) {
        		if(SE.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
        			n = SE.nearestNeighbor(anchor, n);
        		}
        	}
        	
        	if(NW!=null) {
	        	if(NW.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
	        		n = NW.nearestNeighbor(anchor, n);
	        	}
	        }
        	
        	if(NE!=null) {
        		if(NE.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
        			n = NE.nearestNeighbor(anchor, n);
        		}
        	}
        	
        	if(SW!=null) {
	        	if(SW.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
	        		n = SW.nearestNeighbor(anchor, n);
	        	}
	        }
	        
        	
        }else {
        	//* SW -> NW -> NE -> SE

        	if(SW!=null) {
        		if(SW.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
        			 n = SW.nearestNeighbor(anchor, n);
        		}
        	}
        	
        	
	        if(NW!=null) {
	        	if(NW.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
	        		n = NW.nearestNeighbor(anchor, n);
	        	}
	        }
        	
	        if(NE!=null) {
        		if(NE.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
        			n = NE.nearestNeighbor(anchor, n);
        		}
        	}
	        
        	
        	if(SE!=null) {
        		if(SE.doesQuadIntersectAnchorRange(anchor, n.getBestDist())||n.getBestDist()==-1) {
        			n = SE.nearestNeighbor(anchor, n);
        		}
        	}
        	
        }
        
        return n;
    	
    }

    @Override
    public void kNearestNeighbors(int k, KDPoint anchor, BoundedPriorityQueue<KDPoint> queue) {
    	int x_cent = this.centroid.coords[0];
        int y_cent = this.centroid.coords[1];
        int x_anchor = anchor.coords[0];
        int y_anchor = anchor.coords[1];
        
        if(x_anchor>= x_cent&& y_anchor>= y_cent) {
        	//* NE -> NW -> SW -> SE
        	if(NE!=null) {
        		if(queue.size()<k||NE.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
        			NE.kNearestNeighbors(k, anchor, queue);
        		}
        	}
        	
        	
	        if(NW!=null) {
	        	if(queue.size()<k||NW.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
	        		NW.kNearestNeighbors(k, anchor, queue);
	        	}
	        }
        	
        	
        	if(SW!=null) {
        		if(queue.size()<k||SW.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
        			SW.kNearestNeighbors(k, anchor, queue);
        		}
        	}
        	
        	if(SE!=null) {
        		if(queue.size()<k||SE.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
        			SE.kNearestNeighbors(k, anchor, queue);
        		}
        	}
        	
        	
        	
        }else if(x_anchor < x_cent&& y_anchor>= y_cent) {
        	//* NW -> NE -> SW -> SE
        	
	        if(NW!=null) {
	        	if(queue.size()<k||NW.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
	        		NW.kNearestNeighbors(k, anchor, queue);
	        	}
	        }
        	
        	
        	if(NE!=null) {
        		if(queue.size()<k||NE.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
        			NE.kNearestNeighbors(k, anchor, queue);
        		}
        	}
        	
        	
        	if(SW!=null) {
        		if(queue.size()<k||SW.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
        			SW.kNearestNeighbors(k, anchor, queue);
        		}
        	}
        	
        	if(SE!=null) {
        		if(queue.size()<k||SE.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
        			SE.kNearestNeighbors(k, anchor, queue);
        		}
        	}
        	
        }else if(x_anchor>= x_cent&& y_anchor < y_cent) {
        	//* SE -> NW -> NE -> SW
        	
        	if(SE!=null) {
        		if(queue.size()<k||SE.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
        			SE.kNearestNeighbors(k, anchor, queue);
        		}
        	}
        	
        	if(NW!=null) {
	        	if(queue.size()<k||NW.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
	        		NW.kNearestNeighbors(k, anchor, queue);
	        	}
	        }
        	
        	if(NE!=null) {
        		if(queue.size()<k||NE.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
        			NE.kNearestNeighbors(k, anchor, queue);
        		}
        	}
        	
        	if(SW!=null) {
	        	if(queue.size()<k||SW.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
	        		SW.kNearestNeighbors(k, anchor, queue);
	        	}
	        }
	        
        	
        }else {
        	//* SW -> NW -> NE -> SE

        	if(SW!=null) {
        		if(queue.size()<k||SW.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
        			 SW.kNearestNeighbors(k, anchor, queue);
        		}
        	}
        	
        	
	        if(NW!=null) {
	        	if(queue.size()<k||NW.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
	        		NW.kNearestNeighbors(k, anchor, queue);
	        	}
	        }
        	
	        if(NE!=null) {
        		if(queue.size()<k||NE.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
        			NE.kNearestNeighbors(k, anchor, queue);
        		}
        	}
	        
        	
        	if(SE!=null) {
        		if(queue.size()<k||SE.doesQuadIntersectAnchorRange(anchor, queue.get_last_key())) {
        			SE.kNearestNeighbors(k, anchor, queue);
        		}
        	}
        	
        }
    }
    }
 

