package spatial.knnutils;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import spatial.exceptions.UnimplementedMethodException;


/**
 * <p>{@link BoundedPriorityQueue} is a priority queue whose number of elements
 * is bounded. Insertions are such that if the queue's provided capacity is surpassed,
 * its length is not expanded, but rather the maximum priority element is ejected
 * (which could be the element just attempted to be enqueued).</p>
 *
 * <p><b>YOU ***** MUST ***** IMPLEMENT THIS CLASS!</b></p>
 *
 * @author  <a href = "https://github.com/jasonfillipou/">Jason Filippou</a>
 *
 * @see PriorityQueue
 * @see PriorityQueueNode
 */
public class BoundedPriorityQueue<T> implements PriorityQueue<T>{

	/* *********************************************************************** */
	/* *************  PLACE YOUR PRIVATE FIELDS AND METHODS HERE: ************ */
	/* *********************************************************************** */

	
	
	
	
	private int size;
	private TreeMap<Double,ArrayList<T>> list;
	//*private ArrayList<Node> arr;
	private int mody;
	private int count;

	/* *********************************************************************** */
	/* ***************  IMPLEMENT THE FOLLOWING PUBLIC METHODS:  ************ */
	/* *********************************************************************** */

	/**
	 * Constructor that specifies the size of our queue.
	 * @param size The static size of the {@link BoundedPriorityQueue}. Has to be a positive integer.
	 * @throws IllegalArgumentException if size is not a strictly positive integer.
	 */
	public BoundedPriorityQueue(int size) throws IllegalArgumentException{
		if(size <= 0) {
			throw new IllegalArgumentException("not positive");
		}
		
		this.size = size;
		list =  new TreeMap<Double,ArrayList<T>>();
		//*arr = new ArrayList<Node>();
		this.mody = 0;
		count = 0;
	}

	/**
	 * <p>Enqueueing elements for BoundedPriorityQueues works a little bit differently from general case
	 * PriorityQueues. If the queue is not at capacity, the element is inserted at its
	 * appropriate location in the sequence. On the other hand, if the object is at capacity, the element is
	 * inserted in its appropriate spot in the sequence (if such a spot exists, based on its priority) and
	 * the maximum priority element is ejected from the structure.</p>
	 * 
	 * @param element The element to insert in the queue.
	 * @param priority The priority of the element to insert in the queue.
	 */
	@Override
	public void enqueue(T element, double priority) {
		ArrayList<T> arr = new ArrayList<T>();
		
		if(list.containsKey(priority)) {
			arr = list.get(priority);
		}
		
			arr.add(element);
			list.put(priority, arr);
			
			mody ++;
			count ++;
			System.out.println("add: " + element+ " p: "+ priority);
			if(size()>size) {
				//*
				ArrayList<T> change = list.lastEntry().getValue();
				double index = list.lastEntry().getKey();
				
				change.remove(change.size()-1);
				count --;
				if(change.size()==0){
					list.pollLastEntry();
				
				}else{
					list.put(index, change);
				}
			}	
				
			
	}

	@Override
	public T dequeue() {
		if(isEmpty()) {
			System.out.println("empty list can't dequeue");
			return null;
		}
		
		
		System.out.println("dequeue this first");
		mody ++;
		count --;
		
		
		ArrayList<T> change = list.firstEntry().getValue();
		double index = list.firstEntry().getKey();
		
		T output = change.get(0);
		change.remove(0);
		
		if(change.size()==0){
			list.pollFirstEntry();
		
		}else{
			list.put(index, change);
		}
		
		
		return output;
		
	}

	@Override
	public T first() {
		if(isEmpty()) {
			return null;
		}
		
		return list.firstEntry().getValue().get(0);
	}
	
	/**
	 * Returns the last element in the queue. Useful for cases where we want to 
	 * compare the priorities of a given quantity with the maximum priority of 
	 * our stored quantities. In a minheap-based implementation of any {@link PriorityQueue},
	 * this operation would scan O(n) nodes and O(nlogn) links. In an array-based implementation,
	 * it takes constant time.
	 * @return The maximum priority element in our queue, or null if the queue is empty.
	 */
	public T last() {
		if(isEmpty()) {
			return null;
		}
		
		return list.lastEntry().getValue().get(list.lastEntry().getValue().size()-1);
	}

	public double get_last_key() {
		return list.lastEntry().getKey();
		
	}
	
	/**
	 * Inspects whether a given element is in the queue. O(N) complexity.
	 * @param element The element to search for.
	 * @return {@code true} iff {@code element} is in {@code this}, {@code false} otherwise.
	 */
	public boolean contains(T element)
	{
		
		boolean output = false;
		
		for (Map.Entry<Double,ArrayList<T>>
        		entry : list.entrySet())
			if(entry.getValue().contains(element)) {
				output = true;
			};
		
		
		return output;
	}

	@Override
	public int size() {
		
		
		return count;
	}

	@Override
	public boolean isEmpty() {
		return size() == 0;
	}

	@Override
	public Iterator<T> iterator() {
	
		ArrayList<T> copy = new ArrayList<T>();
		
		for (Map.Entry<Double,ArrayList<T>> entry : list.entrySet()) {
			for(int i = 0; i< entry.getValue().size(); i++) {
				copy.add(entry.getValue().get(i));
			}
		};
		
		
		
		int modyvalue = this.mody;

    	Iterator<T> I = new Iterator<T>() {

			@Override
			public boolean hasNext() {
				if(modyvalue!=mody) {
					throw new ConcurrentModificationException();
				}
				return copy.isEmpty() == false;
			}

			@Override
			public T next() {
				
				if(modyvalue!=mody) {
					throw new ConcurrentModificationException();
				}
				
				if(hasNext()) {
				
					return copy.remove(0);
				
				}
				return null;
			}
    		
    		
    	};
		
		
		
		return I;
	}
}
